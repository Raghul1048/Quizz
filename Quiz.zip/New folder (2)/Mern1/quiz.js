const correctAnswers = {
    q1: 'Displays a message in the browser console',
    q2: 'const',
    q3: '11',
    q4: '0',
    q10: 'function myFunction() { }'
};

let currentQuestion = 1;
let score = 0;

function checkAnswer() {
    const answer = document.querySelector(`input[name="q${currentQuestion}"]:checked`);
    if (answer && answer.value === correctAnswers[`q${currentQuestion}`]) {
        score++;
    }
}

function nextQuestion() {
    checkAnswer();
    if (currentQuestion < 10) {
        currentQuestion++;
        displayQuestion();
    } else {
        showResult();
    }
}

function prevQuestion() {
    if (currentQuestion > 1) {
        currentQuestion--;
        displayQuestion();
    }
}

function displayQuestion() {
    const questions = document.querySelectorAll('.question');
    questions.forEach((question, index) => {
        question.style.display = (index === currentQuestion - 1) ? 'block' : 'none';
    });

    document.getElementById('prevBtn').disabled = currentQuestion === 1;
    document.getElementById('nextBtn').textContent = currentQuestion === 10 ? 'Submit' : 'Next';
}

function showResult() {
    document.getElementById('quiz-container').style.display = 'none';
    document.getElementById('result').innerHTML = `
        Your score is: ${score} out of 10 <br>
        ${score === 10 ? 'Excellent! You answered all questions correctly!' : 
         score >= 8 ? 'Great job! You almost got everything right!' :
         score >= 5 ? 'Good effort! You got more than half correct!' :
         'Try again! You can do better next time!'}
    `;
}

displayQuestion();
