

"use strict";

const validUsername = "user";
const validPassword = "password123";


document.getElementById("sign-in-form").addEventListener("submit", function(event) {
  event.preventDefault(); 
  
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (username === validUsername && password === validPassword) {
   
    window.location.href = "quiz.html"; 
  } else {
    
    document.getElementById("error-message").style.display = "block";
  }
});
