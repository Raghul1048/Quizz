"use strict";

function loginUser(event) 
{
  event.preventDefault(); 

  
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  const correctUsername = "user";
  const correctPassword = "password123";

  if (username === correctUsername && password === correctPassword) {
    alert("Login successful! Redirecting to the quiz...");
   
    window.location.href = "quiz.html";
  } else {
    alert("Invalid credentials. Please try again.");
  }
}
